import unittest
from selenium import webdriver
from selenium.webdriver.common.by import By

class TestDarkModeCSS(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Chrome()
        self.driver.get("file:///path/to/your/html/file.html")

    def test_background_color(self):
        # Check background color of body in dark mode
        body_background_color = self.driver.find_element(By.TAG_NAME, "body").value_of_css_property("background-color")
        self.assertEqual(body_background_color, "rgba(255, 255, 255, 1)")

    def test_text_color(self):
        # Check text color in dark mode
        text_color_elements = self.driver.find_elements(By.CSS_SELECTOR, ".dark-mode, .dark-mode input[type='text']")
        for element in text_color_elements:
            color = element.value_of_css_property("color")
            self.assertEqual(color, "rgba(51, 51, 51, 1)")

    def test_border_color(self):
        # Check border color in dark mode
        border_color_elements = self.driver.find_elements(By.CSS_SELECTOR, ".dark-mode input[type='text'], .dark-mode .well, .dark-mode .btn.btn-success")
        for element in border_color_elements:
            body_background_color = self.driver.find_element(By.TAG_NAME, "body").value_of_css_property(
                "background-color")
            self.assertEqual(body_background_color, "rgba(255, 255, 255, 1)")



    def tearDown(self):
        self.driver.quit()

if __name__ == "__main__":
    unittest.main()