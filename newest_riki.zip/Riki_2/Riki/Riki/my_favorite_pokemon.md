title: Raz's Favorite Pokemon
tags: Pokemon

* Lucario
* Zeraora
* Lycanroc
* Arcanine
* Cinderace
* Meowscarada
