# encoding: utf-8

SECRET_KEY='a unique and long key'
TITLE='Riki' 
HISTORY_SHOW_MAX=30
PIC_BASE = '/static/content/'
CONTENT_DIR = 'C:\\Users\peyto\Downloads\Riki_2\Riki\Riki'
USER_DIR = 'C:\\Users\peyto\Downloads\Riki_2\Riki\Riki\\user'
NUMBER_OF_HISTORY = 5
PRIVATE = True
